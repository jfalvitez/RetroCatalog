# RetroCatalog

Catálogo liviano: muestra una lista de juegos desde un JSON remoto (mismo
formato que usamos con Termux: {"items":[{"label","path","core"}]}), y solo
descarga el ROM que elegiste en el momento de tocarlo, directo a la carpeta
que ya tiene configurada Lemuroid. Si el ROM viene en .zip, lo descomprime
solo. Después de guardarlo, abre Lemuroid automáticamente.

## Primer uso
1. Instala Lemuroid y, dentro de Lemuroid, configura su carpeta de juegos
   (Ajustes > Directorio de juegos).
2. Abre RetroCatalog y en "Elegir carpeta" selecciona ESA MISMA carpeta
   (el selector de Android es el mismo para ambas apps).
3. Pega la URL de tu playlist JSON y toca "Cargar lista".
4. Toca cualquier juego: se descarga, se guarda, y se abre Lemuroid. Si
   Lemuroid no lo detecta solo, usa "rescan" ahí dentro una vez.

## Limitaciones conocidas (ver conversación)
- Lemuroid no expone una forma de forzar un rescan desde afuera, así que
  esta app no puede saltar directo al juego: te deja en la pantalla
  principal de Lemuroid y ahí tocas el juego una vez.
- Si ya descargaste un juego antes, el segundo toque no vuelve a bajarlo:
  solo abre Lemuroid directamente.
