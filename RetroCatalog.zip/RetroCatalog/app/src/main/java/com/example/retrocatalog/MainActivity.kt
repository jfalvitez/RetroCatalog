package com.example.retrocatalog

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.net.URL
import java.util.zip.ZipInputStream

// Paquete de Lemuroid instalado en el teléfono
const val LEMUROID_PKG = "com.swordfish.lemuroid"

data class Game(val label: String, val url: String, val core: String)

fun extFor(core: String): String = when (core) {
    "nes" -> "nes"
    "snes9x", "snes" -> "sfc"
    "gba" -> "gba"
    "gb" -> "gb"
    "gbc" -> "gbc"
    "n64" -> "n64"
    "psx" -> "bin"
    "segaMD", "genesis" -> "md"
    else -> "bin"
}

fun safeName(label: String) = label.filter { it.isLetterOrDigit() || it == ' ' || it == '-' }.trim().replace(' ', '_')

fun parsePlaylist(json: String): List<Game> {
    val arr = JSONObject(json).getJSONArray("items")
    return (0 until arr.length()).map {
        val o = arr.getJSONObject(it)
        Game(o.optString("label"), o.getString("path"), o.optString("core", "nes"))
    }
}

// Descarga la URL y, si resulta ser un .zip, devuelve el contenido del archivo
// de adentro que coincida con la extensión esperada (o el primero, si no hay match).
fun downloadAndMaybeUnzip(url: String, expectedExt: String): ByteArray {
    val raw = URL(url).openStream().use { it.readBytes() }
    return try {
        val zis = ZipInputStream(ByteArrayInputStream(raw))
        var entry = zis.nextEntry
        var fallback: ByteArray? = null
        while (entry != null) {
            val bytes = zis.readBytes()
            if (entry.name.endsWith(".$expectedExt", ignoreCase = true)) {
                return bytes
            }
            if (fallback == null && !entry.isDirectory) fallback = bytes
            entry = zis.nextEntry
        }
        fallback ?: raw
    } catch (e: Exception) {
        raw // no era un zip válido: ya es el rom crudo
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App() } }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("p", Context.MODE_PRIVATE) }
    var folderUri by remember {
        mutableStateOf(prefs.getString("folderUri", null)?.let { Uri.parse(it) })
    }
    var playlistUrl by remember { mutableStateOf(prefs.getString("playlistUrl", "") ?: "") }
    var games by remember { mutableStateOf(listOf<Game>()) }
    var status by remember { mutableStateOf(mapOf<String, String>()) }
    var info by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            ctx.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            folderUri = uri
            prefs.edit().putString("folderUri", uri.toString()).apply()
        }
    }

    Column(Modifier.fillMaxSize().systemBarsPadding().padding(16.dp)) {
        Text("1) Elige la MISMA carpeta que configuraste en Lemuroid:")
        Button(onClick = { pickFolder.launch(null) }) {
            Text(if (folderUri != null) "Carpeta elegida ✓" else "Elegir carpeta")
        }
        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            playlistUrl, { playlistUrl = it }, Modifier.fillMaxWidth(),
            label = { Text("URL de la playlist (.json)") }
        )
        Button(onClick = {
            prefs.edit().putString("playlistUrl", playlistUrl).apply()
            scope.launch {
                info = "Cargando..."
                try {
                    games = withContext(Dispatchers.IO) { parsePlaylist(URL(playlistUrl).readText()) }
                    info = "${games.size} juegos"
                } catch (e: Exception) { info = "Error: ${e.message}" }
            }
        }) { Text("Cargar lista") }
        Text(info)

        LazyColumn {
            items(games) { g ->
                ListItem(
                    headlineContent = { Text(g.label) },
                    supportingContent = { Text(status[g.label] ?: g.core) },
                    modifier = Modifier.clickable {
                        if (folderUri == null) {
                            Toast.makeText(ctx, "Primero elige la carpeta", Toast.LENGTH_SHORT).show()
                            return@clickable
                        }
                        val dir = DocumentFile.fromTreeUri(ctx, folderUri!!)
                        val ext = extFor(g.core)
                        val filename = "${safeName(g.label)}.$ext"
                        val existing = dir?.findFile(filename)

                        if (existing != null) {
                            ctx.packageManager.getLaunchIntentForPackage(LEMUROID_PKG)?.let { ctx.startActivity(it) }
                                ?: Toast.makeText(ctx, "Lemuroid no está instalado", Toast.LENGTH_LONG).show()
                            return@clickable
                        }

                        status = status + (g.label to "Descargando...")
                        scope.launch {
                            try {
                                val bytes = withContext(Dispatchers.IO) { downloadAndMaybeUnzip(g.url, ext) }
                                withContext(Dispatchers.IO) {
                                    val file = dir!!.createFile("application/octet-stream", filename)!!
                                    ctx.contentResolver.openOutputStream(file.uri)!!.use { it.write(bytes) }
                                }
                                status = status + (g.label to "Listo ✓")
                                ctx.packageManager.getLaunchIntentForPackage(LEMUROID_PKG)?.let { ctx.startActivity(it) }
                                    ?: Toast.makeText(ctx, "Lemuroid no está instalado", Toast.LENGTH_LONG).show()
                            } catch (e: Exception) {
                                status = status + (g.label to "Error: ${e.message}")
                            }
                        }
                    }
                )
            }
        }
    }
}
